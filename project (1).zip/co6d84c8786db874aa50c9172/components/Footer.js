import React from "react"

export default function Footer(){
    return (
        <div className="footer-section">
            <footer>
                <div className="social--networks">
                    <a href="https://twitter.com/beistroff">
                        <i className="fa-brands fa-square-twitter"></i>
                    </a>
                    <a href="https://www.facebook.com/andrei.galias/">
                        <i className="fa-brands fa-square-facebook"></i> 
                    </a>
                    <a href="https://www.instagram.com/andrewhaliass/">
                        <i className="fa-brands fa-square-instagram"></i>
                    </a>
                    <a href="https://github.com/beistroff">
                        <i className="fa-brands fa-square-github"></i>
                    </a>
                </div>
            </footer>
        </div>
    )
}