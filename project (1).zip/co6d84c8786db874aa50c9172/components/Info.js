import React from "react"
import About from "./About"
import Interests from "./Interests"

export default function Info(){
    return (
        <div className="info-box">
            <img src="../img/myphoto.jpg" className="main--photo"/>
            <div className="info-under-photo">
                <div className="main--info">
                    <h1>Galias Andriy</h1>
                    <h4>UX/UI Designer</h4>
                    <h6>beistroff.website</h6>
                </div>   
                <div className="info--buttons">
                    <div className="email-btn">
                        <a href="https://www.linkedin.com/in/andriy-galias-9ab388244/">
                            <i className="fa-solid fa-envelope"></i>
                            <p className="p--email">Email</p>
                        </a>
                    </div>
                    <div className="linkedin-btn">  
                        <a href="https://www.linkedin.com/in/andriy-galias-9ab388244/">
                            <i className="fa-brands fa-linkedin"></i>
                            <p className="p--linkedin">LinkedIn</p>
                        </a>
                    </div>                
                </div> 
             </div>
             <About /> 
             <Interests />              
        </div>
    )
}